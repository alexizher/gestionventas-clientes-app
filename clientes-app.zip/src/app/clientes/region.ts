export class Region {
  id: number;
  nombre: string;
}
